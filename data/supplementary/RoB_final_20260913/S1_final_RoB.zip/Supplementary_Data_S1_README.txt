Supplementary Data S1 - final critical appraisal

This bundle contains the final, author-approved outcome-specific critical appraisal of 64 locked removal units. X.C.N. and T.U. independently reviewed the relevant original PDF evidence, reconciled disagreements, and jointly accepted the final judgements on 13 September 2026. The unit summary gives final domain and overall judgements. The domain decisions file gives the reviewer judgements, final reconciliation, DOI, and source locator for each domain.
