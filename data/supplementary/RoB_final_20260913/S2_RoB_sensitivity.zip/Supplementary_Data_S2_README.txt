Supplementary Data S2 - risk-of-bias sensitivity analysis

This bundle contains the author-approved sensitivity analysis that excludes valid removal outcomes linked to final Critical concern / insufficient reporting units. It includes the excluded-outcome list, full-versus-restricted cell comparison, analytical report, and machine-readable validation checks. The frozen primary analysis contained 179 valid outcomes; the restricted analysis contained 157 after exclusion of 22 outcomes.
