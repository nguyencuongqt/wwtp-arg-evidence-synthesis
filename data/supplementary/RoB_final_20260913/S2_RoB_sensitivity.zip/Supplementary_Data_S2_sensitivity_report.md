# Risk-of-bias sensitivity analysis

Final analysis date: `2026-09-13`

## Purpose

This sensitivity analysis follows the accepted RoB protocol. It preserves the frozen cohort and tests the impact of excluding outcome rows linked to final `Critical concern / insufficient reporting` appraisal units.

## Locked inputs and scope checks

- Frozen source: `data/m1_axis1_removal_log_reduction_public_v2_20260820.csv` in the cited reproducibility repository.
- Final critical-appraisal table: Supplementary Data S1; final judgements were jointly accepted by X.C.N. and T.U.
- Frozen rows/studies: **181 / 43**.
- Valid primary-analysis rows/studies: **179 / 42**.
- Final Critical units: **12**; valid linked outcomes excluded: **22**.
- Restricted-analysis rows/studies: **157 / 33**.
- The two rows not valid for removal synthesis (both R1070) are absent from both analytic datasets; they were not counted as a RoB exclusion.

## Analysis method

- Baseline: the frozen rows with `valid_for_removal_synthesis = Yes` (not a changed cohort).
- Restricted analysis: baseline minus exactly the 22 valid outcome IDs mapped to final Critical units.
- For each prespecified table/cell, values are summarized at study level. Where its original threshold is met, the script uses DerSimonian–Laird random effects with the project’s frozen-data variance-imputation rule; otherwise results remain descriptive.
- This analysis is an outcome-level sensitivity analysis, not exclusion of whole studies. It does not infer causal certainty from overlapping confidence intervals or from a similar point estimate.

## Main-route comparison (influent to final effluent)

| Gene family | Full: studies / rows | Restricted: studies / rows | Full median | Restricted median | Δ median | Full DL pooled | Restricted DL pooled | Δ pooled |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| bla | 13 / 22 | 11 / 20 | 2.440 | 2.275 | -0.165 | 2.438 | 2.295 | -0.143 |
| erm | 8 / 11 | 6 / 9 | 2.475 | 2.308 | -0.167 | NR | NR | NR |
| intI1 | 7 / 8 | 5 / 6 | 1.400 | 1.360 | -0.040 | NR | NR | NR |
| other | 4 / 4 | 4 / 4 | 2.660 | 2.660 | 0.000 | NR | NR | NR |
| qnr | 2 / 2 | 1 / 1 | 1.825 | 1.000 | -0.825 | NR | NR | NR |
| sul | 10 / 16 | 8 / 13 | 2.100 | 2.645 | 0.545 | 2.261 | NR | NR |
| tet | 11 / 18 | 9 / 16 | 2.000 | 2.000 | 0.000 | 2.367 | NR | NR |

`NR` = not estimated because the prespecified minimum number of studies was not met in that analysis cell.

## Key sensitivity findings

- Across all genes on the main influent-to-final-effluent route, the DL pooled estimate changed from 2.219 to 2.203 log10 reduction (−0.016); heterogeneity remained extreme (I² 99.48% to 99.54%).
- The biological-treatment pooled estimate changed from 1.571 to 1.477 log10 reduction (−0.094; I² 85.45% to 87.65%). The disinfection estimate was essentially unchanged: 2.073 to 2.078 log10 reduction (+0.005; I² about 99%).
- For the main route, `bla` remained eligible for a DL estimate (2.438 to 2.295 log10 reduction). `sul` and `tet` fell below the pre-specified threshold of 10 studies after the exclusion and therefore have no restricted pooled DL estimate; they remain descriptive in the sensitivity analysis.
- The full valid-row baseline reproduces all seven cells of the project’s published A1 main-route table exactly; the independent validation result is recorded in `RoB_sensitivity_validation_20260913.json`.

## Interpretation boundary

The comparison files provide the numerical robustness check. They must be interpreted as a sensitivity to exclusion of critically appraised evidence, not as proof that the remaining evidence is unbiased. Any manuscript wording should retain the high heterogeneity and reporting limitations documented by the primary synthesis and RoB appraisal.

## Files in this bundle

- `Supplementary_Data_S2_excluded_outcomes.csv`: the 22 excluded valid outcomes and their final Critical units.
- `Supplementary_Data_S2_full_vs_restricted_comparison.csv`: numerical full and restricted estimates by cell.
- `Supplementary_Data_S2_validation.json`: machine-readable scope and integrity checks.
