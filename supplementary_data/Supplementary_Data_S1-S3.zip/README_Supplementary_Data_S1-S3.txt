Supplementary Data S1–S3
This archive groups the three machine-readable supplementary data sets cited in the manuscript. The Data_S1, Data_S2 and Data_S3 folders preserve the dataset identifiers used in the text.

Data_S1: critical-appraisal domain decisions, unit summaries, and mapping to the final v4 dataset.
Data_S2: critical-concern outcomes and full-versus-restricted sensitivity results, including supporting tables and validation records.
Data_S3: supporting screening, provenance, study-characteristic, route, treatment, abundance, detection, and evidence-boundary tables.

Use the README within each folder for dataset-specific scope and interpretation. File-level records are supplied in their original CSV, JSON, TXT, and Markdown formats.
